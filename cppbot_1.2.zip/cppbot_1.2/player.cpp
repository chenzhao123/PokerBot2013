#include <iostream>
#include "player.hpp"
#include <stdlib.h>
#include <cmath>
#include "pbots_calc.h"

Player::Player() {
	//create_equity250();
}

/**
 * Simple example pokerbot, written in C++.
 *
 * This is an example of a bare bones pokerbot. It only sets up the socket
 * necessary to connect with the engine (using a Boost iostream for
 * convenience) and then always returns the same action.  It is meant as an
 * example of how a pokerbot should communicate with the engine.
 */
void Player::run(tcp::iostream &stream) {
	std::string line;
	while (std::getline(stream, line)) {
		// For now, just print out whatever date is read in.
		std::cout << line << "\n";
		std::string getaction("GETACTION");
		std::string request_keyvalue_action("REQUESTKEYVALUES");
		std::string newgame("NEWGAME");
		std::string keyvalue("KEYVALUE");
		std::string newhand("NEWHAND");
		std::string handover("HANDOVER");
		std::string first_word = line.substr(0, line.find_first_of(' '));
		if (newgame.compare(first_word) == 0) {
			//Call handle new game
			new_game(line.substr(line.find_first_of(' ')+1));
		} else if (getaction.compare(first_word) == 0) {
			// Respond with CHECK when playing, you'll want to change this.
			get_action(line.substr(line.find_first_of(' ')+1));
			get_action_respond(stream);
			//stream << "CHECK\n";
		} else if (request_keyvalue_action.compare(first_word) == 0) {
		
			// tests
			//std::cout << player1 << " " << player2 << " " << num_hands << " " << my_bank << "\n";
			//for (int i=0; i<10; i++)
			//	std::cout << action_list[i][0].action << ":" 
			//						<< action_list[i][0].actor << "\n";
			// end tests


			// FINISh indicates no more keyvalue pairs to store.
			stream << "FINISH\n";
		} else if (keyvalue.compare(first_word) == 0){
			//Call handle keyvalue
		} else if (newhand.compare(first_word) == 0){
			//Call handle newhand
			new_hand(line.substr(line.find_first_of(' ')+1));
		} else if (handover.compare(first_word) == 0){
			//Call handle handover
			hand_over(line.substr(line.find_first_of(' ')+1));
		}

	}

	std::cout << "Gameover, engine disconnected.\n";
}

void Player::new_game(std::string line){
	int space_index = line.find_first_of(' ');
	player1 = line.substr(0, space_index);
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	player2 = line.substr(0, space_index);
	line = line.substr(space_index+1);
	
	space_index = line.find_first_of(' ');
	start_stack = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	big_blind = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	num_hands = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	start_time = atof(line.c_str());

}

void Player::new_hand(std::string line){
	int space_index = line.find_first_of(' ');
	hand_id = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	button = !(line.substr(0, space_index).compare("true"));	
	// button=1 if string==true, else button=0
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	std::string c1 = line.substr(0, space_index);
	card1.rank = c1[0];
	card1.suit = c1[1];
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	std::string c2 = line.substr(0, space_index);
	card2.rank = c2[0];
	card2.suit = c2[1];
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	std::string c3 = line.substr(0, space_index);
	card3.rank = c3[0];
	card3.suit = c3[1];
	line = line.substr(space_index+1);

	hands[hand_id-1].cards[0] = card1;
	hands[hand_id-1].cards[1] = card2;
	hands[hand_id-1].cards[2] = card3;

	space_index = line.find_first_of(' ');
  my_bank = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	opp_bank = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	time_bank = atof(line.c_str());

}

void Player::get_action(std::string line){
	int space_index, colon_index;

	space_index = line.find_first_of(' ');
	pot_size = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	num_boardcards = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	for(int i=0; i<num_boardcards; i++) {
		space_index = line.find_first_of(' ');
		std::string c = line.substr(0, space_index);
		Card card;
		card.rank = c[0];
		card.suit = c[1];
		hands[hand_id%NUM_HANDS-1].cards[i+3] = card; // keep track of last 1000 hands
		line = line.substr(space_index+1);
	}

	space_index = line.find_first_of(' ');
	int num_lastactions = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	for(int i=0; i<num_lastactions; i++) {
		space_index = line.find_first_of(' ');
		std::string actstr = line.substr(0, space_index); // string of one action
		PerformedAction act;
		// find : separator
		colon_index = actstr.find_first_of(':');
		act.action = actstr.substr(0, colon_index);
		if (act.action.compare("BET") == 0 || act.action.compare("POST") == 0 || 
				act.action.compare("RAISE") == 0 || act.action.compare("REFUND") == 0 || 
				act.action.compare("TIE") == 0 || act.action.compare("WIN") == 0){
				actstr = actstr.substr(colon_index+1);
			colon_index = actstr.find_first_of(':');
			act.amount = atoi(actstr.substr(0, colon_index).c_str());
			act.actor = actstr.substr(colon_index+1);
		} else if (act.action.compare("CALL") == 0 || act.action.compare("CHECK") == 0 || 
				act.action.compare("FOLD") == 0){
			act.actor = actstr.substr(colon_index+1);
		} else if (act.action.compare("DEAL") == 0){
      act.street = actstr.substr(colon_index+1);
		} else if (act.action.compare("SHOW") == 0){
			actstr= actstr.substr(colon_index+1);
			colon_index = actstr.find_first_of(':');
			act.showcard1 = str_to_card(actstr.substr(0, colon_index));
			actstr = actstr.substr(colon_index+1);
			colon_index = actstr.find_first_of(':');
			act.showcard2 = str_to_card(actstr.substr(0, colon_index));
			act.actor = actstr.substr(colon_index+1);
    }

		action_list[hand_id%NUM_HANDS-1].push_back(act);	// add act to action_list
	  line = line.substr(space_index+1);
	}

  space_index = line.find_first_of(' ');
  int num_legalactions = atoi(line.substr(0, space_index).c_str());
  line = line.substr(space_index+1);

  for(int i=0; i<num_legalactions; i++) {
    space_index = line.find_first_of(' ');
		std::string actstr = line.substr(0, space_index);
	  LegalAction act;
	  // find : separator
	  colon_index = actstr.find_first_of(':');
	  act.action = actstr.substr(0, colon_index);
	  if (act.action.compare("BET") == 0 || act.action.compare("RAISE") == 0){
      actstr = actstr.substr(colon_index+1);
			colon_index = actstr.find_first_of(':');
			act.min = atoi(actstr.substr(0, colon_index).c_str());
			act.max = atoi(actstr.substr(colon_index+1).c_str());
		} 

	  legal_actions.insert(act); // add act to legal_actions
	  line = line.substr(space_index+1);	
	}	
  
	time_bank = atof(line.c_str());
	

} // end get_action(std::string line)

void Player::hand_over(std::string line){
  int space_index, colon_index;
	 
	space_index	= line.find_first_of(' ');
	my_bank = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	opp_bank = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	space_index = line.find_first_of(' ');
	num_boardcards = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

  for(int i=0; i<num_boardcards; i++) {
		space_index = line.find_first_of(' ');
	  std::string c = line.substr(0, space_index);
		Card card;
	  card.rank = c[0];
	  card.suit = c[1];
		hands[hand_id%NUM_HANDS-1].cards[i+3] = card; // keep track of last 1000 hands
	  line = line.substr(space_index+1);
	}

	space_index = line.find_first_of(' ');
	int num_lastactions = atoi(line.substr(0, space_index).c_str());
	line = line.substr(space_index+1);

	for(int i=0; i<num_lastactions; i++) {
		space_index = line.find_first_of(' ');
		std::string actstr = line.substr(0, space_index); // string of one action
		PerformedAction act;
		// find : separator
		colon_index = actstr.find_first_of(':');
    act.action = actstr.substr(0, colon_index);
	  if (act.action.compare("BET") == 0 || act.action.compare("POST") == 0 || 
				act.action.compare("RAISE") == 0 || act.action.compare("REFUND") == 0 || 
				act.action.compare("TIE") == 0 || act.action.compare("WIN") == 0){
      actstr = actstr.substr(colon_index+1);
			colon_index = actstr.find_first_of(':');
			act.amount = atoi(actstr.substr(0, colon_index).c_str());
		  act.actor = actstr.substr(colon_index+1);
		} else if (act.action.compare("CALL") == 0 || act.action.compare("CHECK") == 0 || 
				act.action.compare("FOLD") == 0){
      act.actor = actstr.substr(colon_index+1);
		} else if (act.action.compare("DEAL") == 0){
      act.street = actstr.substr(colon_index+1);
		} else if (act.action.compare("SHOW") == 0){
			actstr= actstr.substr(colon_index+1);
			colon_index = actstr.find_first_of(':');
			act.showcard1 = str_to_card(actstr.substr(0, colon_index));
			actstr = actstr.substr(colon_index+1);
			colon_index = actstr.find_first_of(':');
			act.showcard2 = str_to_card(actstr.substr(0, colon_index));
			act.actor = actstr.substr(colon_index+1);
    }

		action_list[hand_id%NUM_HANDS-1].push_back(act);	// add act to action_list
	  line = line.substr(space_index+1);
	}

  time_bank = atof(line.c_str());

}

void Player::get_action_respond(tcp::iostream &stream){
  if (num_boardcards == 0){         // Pre-flop    
		get_preflop_action(stream);			
	} else if (num_boardcards == 3) { // Flop
    //stream << "CHECK\n";
    get_postflop_action(stream);
    std::cout << "discarded ==== " << discarded.rank << discarded.suit << std::endl; 
	} else if (num_boardcards == 4) { // Turn
    //stream << "CHECK\n";
    get_postflop_action(stream); 
		//get_turn_action(stream);
	} else if (num_boardcards == 5) { // River
		//stream << "CHECK\n";
    get_postflop_action(stream); 
    //get_river_action(stream);
	}
}

void Player::get_preflop_action(tcp::iostream &stream){
	int bet = 4 * compute_betsize_model1(card1, card2, card3);
	if (button) {  // Dealer
		PerformedAction opp_action = *(action_list[hand_id%NUM_HANDS-1].end()-1);
		if ((opp_action.action).compare("POST") == 0) {
			if (bet < 16) stream << "FOLD\n";
			else if (bet < 24) stream << "CALL\n";
			else stream << "RAISE:" << bet << "\n";
		} else if ((opp_action.action).compare("RAISE") == 0){
			int raise_amount = opp_action.amount;
			if (bet < 16) stream << "FOLD\n";
			else if (bet < 24) {
				if (raise_amount <= bet) stream << "CALL\n";
				else stream << "FOLD\n";
			} else {
				int min_raise = 0;
				int max_raise = 0;
				for (std::set<LegalAction>::iterator it=legal_actions.begin(); it != legal_actions.end(); ++it){
        if ((it->action).compare("RAISE")) {
          min_raise = it->min;
						max_raise = it->max;
						break;
					}
				}
				if (raise_amount > bet*1.5) stream << "FOLD\n";
				else if (raise_amount <= bet*1.5 && bet < min_raise) stream << "CALL\n";
				else if (bet >= min_raise && bet <= max_raise) stream << "RAISE:" << bet << "\n";
				else if (bet > max_raise) stream << "RAISE:" << max_raise << "\n";
			}
		}
	} else {  // Big Blind
	PerformedAction opp_action = *(action_list[hand_id%NUM_HANDS-1].end()-1);
		if ((opp_action.action).compare("CALL") == 0){
    if (bet < 24) stream << "CHECK\n";
			else stream << "RAISE:" << bet << "\n";
		} else if ((opp_action.action).compare("RAISE") == 0) {
    int raise_amount = opp_action.amount;
			if (bet < 16) stream << "FOLD\n";
			else if (bet < 24) {
      if (raise_amount <= bet) stream << "CALL\n";
				else stream << "FOLD\n";
			} else {
				int min_raise = 0;
				int max_raise = 0;
				for (std::set<LegalAction>::iterator it=legal_actions.begin(); it != legal_actions.end(); ++it){
        if ((it->action).compare("RAISE")) {
          min_raise = it->min;
						max_raise = it->max;
						break;
					}
				}
				if (raise_amount > bet*1.5) stream << "FOLD\n";
				else if (raise_amount <= bet*1.5 && bet < min_raise) stream << "CALL\n";
				else if (bet >= min_raise && bet <= max_raise) stream << "RAISE:" << bet << "\n";
				else if (bet > max_raise) stream << "RAISE:" << max_raise << "\n";
			} 
		}
	}
}

void Player::get_postflop_action(tcp::iostream &stream){

  PerformedAction last_action = *(action_list[hand_id%NUM_HANDS-1].end()-1);
  calculate_equity_random_opp();
  
  LegalAction discard_act;
  discard_act.action = "DISCARD";
  if (legal_actions.find(discard_act) != legal_actions.end()){
    stream << "DISCARD:" << discarded.rank << discarded.suit << "\n";
    return;
  }
  
  int constant = 2;
  int bet = my_equity * pot_size * constant;
  int variance = rand() % ((int) (.4*bet)) - (bet*0.2);
  int bet_final = bet+variance;

  int max_amt = 400;
  int min_amt = 2;
  LegalAction bet_act;
  LegalAction raise_act;
  bet_act.action = "BET";
  raise_act.action = "RAISE";
  if (legal_actions.find(bet_act) != legal_actions.end()){
    //LegalAction act = *(legal_actions.find(bet_act));
    //max_amt = act.max; 
    //min_amt = act.min;
  }
  if (legal_actions.find(raise_act) != legal_actions.end()){
    //LegalAction act = *(legal_actions.find(raise_act));
    //max_amt = act.max; 
    //min_amt = act.min;
  }

  if (bet_final > max_amt) {
    bet_final = max_amt;
  }
  if (bet_final < min_amt) {
    bet_final = min_amt;
  }

  if (my_equity < 0.5){
    if (button){
      if ((last_action.action).compare("CHECK")==0) {
        stream << "CHECK\n";
      } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
        int raise_amount = last_action.amount;
        if (raise_amount < (my_equity * pot_size)){
          stream << "CALL\n";
        } else {
          stream << "FOLD\n";
        }
      }
    } else {
      if ((last_action.action).compare("DEAL") == 0){
        stream << "CHECK\n";
      } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
        int raise_amount = last_action.amount;
        if (raise_amount < (my_equity * pot_size)){
          stream << "CALL\n";
        } else {
          stream << "FOLD\n";
        }
      }
    }
  } else if (my_equity < 0.8) {
    if (button){
      if ((last_action.action).compare("CHECK")==0) {
        stream << "BET:" << bet_final << "\n" ;
      } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
        int raise_amount = last_action.amount;
        if (bet > 2*raise_amount) {
          stream << "RAISE:" << bet_final << "\n";
        } else if (raise_amount < 2*bet){
          stream << "CALL\n";
        } else {
          stream << "FOLD\n";
        }
      }
    } else {
      if ((last_action.action).compare("DEAL") == 0){
        stream << "BET:" << bet_final << "\n" ;
      } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
        int raise_amount = last_action.amount;
        if (bet > 2*raise_amount) {
          stream << "RAISE:" << bet_final << "\n";
        } else if (raise_amount < 2*bet){
          stream << "CALL\n";
        } else {
          stream << "FOLD\n";
        }
      }
    }
  } else {
    if (button){
      if ((last_action.action).compare("CHECK")==0) {
        stream << "BET:" << bet_final << "\n" ;
      } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
        int raise_amount = last_action.amount;
        if (bet > 2*raise_amount) {
          stream << "RAISE:" << bet_final << "\n";
        } else {
          stream << "CALL\n";
        } 
      }  
    } else {
      if ((last_action.action).compare("DEAL")==0) {
        stream << "BET:" << bet_final << "\n" ;
      } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
        int raise_amount = last_action.amount;
        if (bet > 2*raise_amount) {
          stream << "RAISE:" << bet_final << "\n";
        } else {
          stream << "CALL\n";
        } 
      } 
    }
  }
}


void Player::get_turn_action(tcp::iostream &stream){
  
  PerformedAction last_action = *(action_list[hand_id%NUM_HANDS-1].end()-1);

  if (button) { // go last, see last action
    if ((last_action.action).compare("CHECK")==0) {
      // TODO
      // compute bet amount
      // stream CHECK or BET:bet

      stream << "CHECK\n";  // for now

    } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
      int raise_amount = last_action.amount;
      // TODO
      // compute bet amount
      // stream FOLD, CALL, or RAISE:amount

      stream << "CALL\n"; // for now
    } 

  } else {
    //go first if last action is "DEAL"
    //check last_action (for CHECK and BET and RAISE)
    if ((last_action.action).compare("DEAL") == 0) { // our first action after deal
      // TODO
      // compute bet amount 
      // stream CHECK or BET:bet
      stream << "CHECK\n";   // for now

    } else if ((last_action.action).compare("BET") || 
              (last_action.action).compare("RAISE")) {
      int raise_amount = last_action.amount;
      // TODO
      // compute bet amount
      // stream FOLD, CALL, or RAISE:amount
      stream << "CALL\n";    // for now
    }
  }
}


void Player::get_river_action(tcp::iostream &stream){
  
  PerformedAction last_action = *(action_list[hand_id%NUM_HANDS-1].end()-1);

  if (button) { // go last, see last action
    if ((last_action.action).compare("CHECK")==0) {
      // TODO
      // compute bet amount
      // stream CHECK or BET:bet

      stream << "CHECK\n";  // for now

    } else if ((last_action.action).compare("BET") ||
              (last_action.action).compare("RAISE")) {
      int raise_amount = last_action.amount;
      // TODO
      // compute bet amount
      // stream FOLD, CALL, or RAISE:amount

      stream << "CALL\n"; // for now
    } 

  } else {
    //go first if last action is "DEAL"
    //check last_action (for CHECK and BET and RAISE)
    if ((last_action.action).compare("DEAL") == 0) { // our first action after deal
      // TODO
      // compute bet amount 
      // stream CHECK or BET:bet
      stream << "CHECK\n";   // for now

    } else if ((last_action.action).compare("BET") || 
              (last_action.action).compare("RAISE")) {
      int raise_amount = last_action.amount;
      // TODO
      // compute bet amount
      // stream FOLD, CALL, or RAISE:amount
      stream << "CALL\n";    // for now
    }
  }
}


void Player::calculate_equity_random_opp(){
  
  Card c;
  char board_cards [num_boardcards * 2+1]; 
  for (int i = 0; i < num_boardcards; i++){
    c = hands[hand_id%NUM_HANDS-1].cards[i+3];
    board_cards[i*2] = c.rank;
    board_cards[i*2 + 1] = c.suit; 
  }
  board_cards[num_boardcards*2] = '\0';
  char* board = board_cards;

  if (num_boardcards == 0) { //Pre-flop
    char hand[] = {card1.rank, card1.suit, card2.rank, card2.suit, card3.rank, card3.suit, ':', 'x', 'x','\0'};
    char* myhand = hand;
    Results* res = alloc_results();
    calc(myhand, "", "", 1000, res);
    my_equity = *((res->ev)+0);
    opp_equity = *((res->ev)+1);
  } else if (num_boardcards == 3){ //Flop
    char hand1[] = {card1.rank, card1.suit, card2.rank, card2.suit, ':', 'x', 'x','\0'};
    char hand2[] = {card1.rank, card1.suit, card3.rank, card3.suit, ':', 'x', 'x','\0'};
    char hand3[] = {card2.rank, card2.suit, card3.rank, card3.suit, ':', 'x', 'x','\0'};

    //std::cout << card1.rank << card1.suit << card2.rank << card2.suit << card3.rank << card3.suit << std::endl;
    
    char* myhand = hand1;
    char dead_card[] = {card3.rank, card3.suit,'\0'};
    char* dead = dead_card;
    Results* res1 = alloc_results();


    std::cout << myhand << "\n";
    std::cout << board << "\n";
    std::cout << dead << "\n";

    calc(myhand, board, dead, 1000, res1);


    myhand = hand2;
    dead_card[0] = card2.rank;
    dead_card[1] = card2.suit;
    Results* res2 = alloc_results();

    std::cout << myhand << "\n";
    std::cout << board << "\n";
    std::cout << dead << "\n";

    calc(myhand, board, dead, 1000, res2);

    myhand = hand3;
    dead_card[0] = card1.rank;
    dead_card[1] = card1.suit;
    Results* res3 = alloc_results();

    std::cout << myhand << "\n";
    std::cout << board << "\n";
    std::cout << dead << "\n";

    calc(myhand, board, dead, 1000, res3);

    double eq1 = *((res1->ev)+0);
    double eq2 = *((res2->ev)+0);
    double eq3 = *((res3->ev)+0);

    std::cout << eq1 << " | " << eq2 << " | " << eq3 << std::endl;
    std::cout << *((res1->ev)+0) << " | " 
              << *((res1->ev)+1) << " | " 
              << *((res1->ev)+2) << std::endl;

    if (eq1 > eq2){
      if (eq2 > eq3){
        // Discard card3
        used_cards[0] = card1;
        used_cards[1] = card2;
        discarded = card3;        
        my_equity = eq1;
        opp_equity = 1-my_equity;
      } else {
        // Discard card2
        used_cards[0] = card1;
        used_cards[1] = card3;
        discarded = card2;
        my_equity = eq2;
        opp_equity = 1-my_equity;
      }
    } else {
      if (eq1 > eq3){
        // Discard card3
        used_cards[0] = card1;
        used_cards[1] = card2;
        discarded = card3;
        my_equity = eq1;
        opp_equity = 1-my_equity;
      } else {
        // Discard card1
        used_cards[0] = card2;
        used_cards[1] = card3;
        discarded = card1;
        my_equity = eq3;
        opp_equity = 1-my_equity;
      }
    }
    std::cout << discarded.rank << discarded.suit << " " << my_equity << std::endl;
  } else { //Turn or River
    char hand[] = {used_cards[0].rank, used_cards[0].suit, used_cards[1].rank, used_cards[1].suit, ':', 'x', 'x','\0'};
    char dead_card[] = {discarded.rank, discarded.suit,'\0'};
    char* myhand = hand;
    char* dead = dead_card;
    Results* res = alloc_results();
    calc(myhand, board, dead, 1000, res);
    my_equity = *((res->ev)+0);
    opp_equity = *((res->ev)+1);
  }
}

/*
input: string of 2 characters: rank, suit
returns: Card instance 
*/
Card Player::str_to_card(std::string str) {
	Card c;
	c.rank = str[0];
	c.suit = str[1];
	return c;
}


int Player::rank_to_int(char r) {
	if (r >= '2' && r <= '9') return r - '0';
	else if (r=='T') return 10;
	else if (r=='J') return 11;
	else if (r=='Q') return 12;
	else if (r=='K') return 13;
	else if (r=='A') return 14;
	else return 0;
}

int Player::compute_betsize_model1(Card c1, Card c2, Card c3) {

	int r1, r2, r3;
	r1 = rank_to_int(c1.rank);
	r2 = rank_to_int(c2.rank);
	r3 = rank_to_int(c3.rank);
	
	char s1, s2, s3;
	s1 = c1.suit;
	s2 = c2.suit;
	s3 = c3.suit;

	int sum = 2*(r1 + r2 + r3);
	if (r1 == r2 && r1 == r3) return sum/6 - 2;           		 // 3 of a kind
	else if (r1 == r2 || r1 == r3 || r2 == r3) sum+=13;  // 2 of a kind

	if (s1 == s2 && s1 == s3) sum+=4;                    // 3 suited
	else if (s1 == s2 || s1 == s3 || s2 == s3) sum+=8;   // 2 suited

	// connectors
	int diff3 = abs(r1-r2);
	int diff2 = abs(r1-r2);
	int diff1 = abs(r2-r3);
	if (0<diff3 && diff3<5) sum+=(5-diff3)/2;  // smaller difference = better, divide by 2
	if (0<diff2 && diff2<5) sum+=(5-diff2)/2;
	if (0<diff1 && diff1<5) sum+=(5-diff1)/2;

	return sum/6-2; // how much to bet to
}


int Player::compute_betsize_model2(Card c1, Card c2, Card c3) {

	int r1, r2, r3;
	r1 = rank_to_int(c1.rank);
	r2 = rank_to_int(c2.rank);
	r3 = rank_to_int(c3.rank);
	
	char s1, s2, s3;
	s1 = c1.suit;
	s2 = c2.suit;
	s3 = c3.suit;

	int sum = r1 + r2 + r3;
	if (r1 == r2 && r1 == r3) return sum;           		 // 3 of a kind
	else if (r1 == r2 || r1 == r3 || r2 == r3) sum+=13;  // 2 of a kind

	if (s1 == s2 && s1 == s3) sum+=4;                    // 3 suited
	else if (s1 == s2 || s1 == s3 || s2 == s3) sum+=8;   // 2 suited

	// connectors
	int diff3 = abs(r1-r2);
	int diff2 = abs(r1-r2);
	int diff1 = abs(r2-r3);
	if (0<diff3 && diff3<5) sum+=(5-diff3);
	if (0<diff2 && diff2<5) sum+=(5-diff2);
	if (0<diff1 && diff1<5) sum+=(5-diff1);

	return sum/6;
}

//double Player::preflop_raise_stats()






void Player::create_equity250() {	

}
