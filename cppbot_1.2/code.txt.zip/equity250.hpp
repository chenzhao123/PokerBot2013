#include "Player.hpp"

void Player::create_equity250(){
  set<Card> set1
}
